# Page Table & TLB Simulator

A menu-driven C simulation of virtual-address translation using a fixed page table and a small Translation Lookaside Buffer (TLB). This is an educational simulation; it does not modify the operating system's real page tables or physical memory.

## Project contents

- `src/page_tlb.c` — complete C implementation.
- `presentations/` — all available review/presentation PPT versions retained for the project.
- `documentation/Page_Table_TLB_Simulator_Project_Report.docx` — editable final project report.
- `documentation/Page_Table_TLB_Simulator_Project_Report.pdf` — PDF copy of the report.
- `test-results/sample-test-transcript.txt` — sample run and expected key results.

## Features

- Translate a decimal virtual address into page number and offset.
- Look up page-to-frame mappings in the TLB and page table.
- Report TLB hits, TLB misses, and unmapped-page faults.
- Display the page table, TLB, and translation statistics.
- Reset the TLB and run built-in sample tests.
- Use a 4,096-byte page and a three-entry circular TLB replacement scheme.

## Requirements

- GCC (or another C compiler compatible with C11)
- Linux, macOS, WSL, or a Windows C development environment

## Compile and run

From the repository root:

```bash
gcc -std=c11 -Wall -Wextra src/page_tlb.c -o page_tlb
./page_tlb
```

On Windows using MinGW GCC, run the compiler command and then `page_tlb.exe`.

## Example test cases

| Virtual address | Page | Offset | Mapping/result |
|---:|---:|---:|---|
| 4098 | 1 | 2 | Page 1 → frame 5; physical address 20482 |
| 4098 (second access in the same session) | 1 | 2 | TLB hit; physical address 20482 |
| 8192 | 2 | 0 | Page 2 → frame 1; physical address 4096 |
| 20480 | 5 | 0 | Page 5 is outside the configured page table; reports a page fault |

The initial page table mapping is `page 0 → frame 3`, `page 1 → frame 5`, `page 2 → frame 1`, `page 3 → frame 7`, and `page 4 → frame 8`.

## Team

- 2510030197 — B. Varshith
- 2510030127 — Srinikesh
- 2510039436 — Amr Mansoori
- 2510030019 — Girish Kumar

KLH Deemed to be University — Department of Computer Science and Engineering.

## Notes

- A TLB miss means the mapping was not cached; the page table may still contain the mapping.
- A page fault in this simulator means the requested page is not mapped by the fixed five-entry page table.
- Built-in tests reset the TLB but retain cumulative statistics for the current program session.
- Input validation and further configurable simulation options can be added as future improvements.
