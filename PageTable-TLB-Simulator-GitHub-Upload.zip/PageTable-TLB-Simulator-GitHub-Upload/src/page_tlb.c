#include <stdio.h>
#include <stdlib.h>
 
#define PAGE_SIZE 4096
#define OFFSET_BITS 12
#define TOTAL_PAGES 5
#define TLB_SIZE 3
 
int page_table[TOTAL_PAGES] = {3, 5, 1, 7, 8};
 
typedef struct {
    int valid;
    unsigned int page;
    int frame;
} TLBEntry;
 
typedef struct {
    int total_translations;
    int tlb_hits;
    int tlb_misses;
    int page_faults;
} Statistics;
 
void display_page_table(void) {
    printf("\n========================================\n");
    printf("              PAGE TABLE\n");
    printf("========================================\n");
    printf("%-12s %-12s\n", "Page", "Frame");
    printf("----------------------------------------\n");
    for (int i = 0; i < TOTAL_PAGES; i++) {
        printf("%-12d %-12d\n", i, page_table[i]);
    }
}
 
void display_tlb(TLBEntry tlb[]) {
    printf("\n========================================\n");
    printf("                 TLB\n");
    printf("========================================\n");
    printf("%-8s %-12s %-12s\n", "Entry", "Page", "Frame");
    printf("----------------------------------------\n");
    for (int i = 0; i < TLB_SIZE; i++) {
        if (tlb[i].valid) {
            printf("%-8d %-12u %-12d\n", i, tlb[i].page, tlb[i].frame);
        } else {
            printf("%-8d %-12s %-12s\n", i, "Empty", "Empty");
        }
    }
}
 
int lookup_tlb(TLBEntry tlb[], unsigned int page_number) {
    for (int i = 0; i < TLB_SIZE; i++) {
        if (tlb[i].valid && tlb[i].page == page_number) {
            return tlb[i].frame;
        }
    }
    return -1;
}
 
void update_tlb(TLBEntry tlb[], int *next_tlb_entry,
                unsigned int page_number, int frame_number) {
    tlb[*next_tlb_entry].valid = 1;
    tlb[*next_tlb_entry].page = page_number;
    tlb[*next_tlb_entry].frame = frame_number;
    printf("TLB Entry %d updated: Page %u -> Frame %d\n",
           *next_tlb_entry, page_number, frame_number);
    *next_tlb_entry = (*next_tlb_entry + 1) % TLB_SIZE;
}
 
void reset_tlb(TLBEntry tlb[], int *next_tlb_entry) {
    for (int i = 0; i < TLB_SIZE; i++) {
        tlb[i].valid = 0;
        tlb[i].page = 0;
        tlb[i].frame = 0;
    }
    *next_tlb_entry = 0;
    printf("\nTLB has been reset successfully.\n");
}
 
void display_statistics(Statistics *stats) {
    double hit_rate = 0.0;
    if (stats->total_translations > 0) {
        hit_rate = ((double)stats->tlb_hits / stats->total_translations) * 100.0;
    }
    printf("\n========================================\n");
    printf("        TRANSLATION STATISTICS\n");
    printf("========================================\n");
    printf("Total Translations : %d\n", stats->total_translations);
    printf("TLB Hits           : %d\n", stats->tlb_hits);
    printf("TLB Misses         : %d\n", stats->tlb_misses);
    printf("Page Faults        : %d\n", stats->page_faults);
    printf("TLB Hit Rate       : %.2f%%\n", hit_rate);
    printf("----------------------------------------\n");
}
 
void translate_address(TLBEntry tlb[], int *next_tlb_entry,
                       unsigned int virtual_address, Statistics *stats) {
    unsigned int mask = PAGE_SIZE - 1;
    unsigned int page_number = virtual_address >> OFFSET_BITS;
    unsigned int offset = virtual_address & mask;
 
    printf("\n========================================\n");
    printf("        ADDRESS TRANSLATION\n");
    printf("========================================\n");
    printf("Virtual Address : %u\n", virtual_address);
    printf("Page Size       : %d bytes\n", PAGE_SIZE);
    printf("Page Number     : %u\n", page_number);
    printf("Offset          : %u\n", offset);
 
    stats->total_translations++;
    printf("\nTLB Lookup...\n");
    int frame_number = lookup_tlb(tlb, page_number);
    int tlb_hit = 0;
 
    if (frame_number != -1) {
        tlb_hit = 1;
        stats->tlb_hits++;
        printf("TLB HIT!\n");
        printf("Frame Number    : %d\n", frame_number);
    } else {
        stats->tlb_misses++;
        printf("TLB MISS!\n");
        printf("\nPage Table Lookup...\n");
 
        if (page_number >= TOTAL_PAGES) {
            stats->page_faults++;
            printf("Page %u is not mapped.\n", page_number);
            printf("\nPAGE FAULT: Unmapped Address\n");
            return;
        }
 
        frame_number = page_table[page_number];
        printf("Page Number     : %u\n", page_number);
        printf("Frame Number    : %d\n", frame_number);
        printf("\nUpdating TLB...\n");
        update_tlb(tlb, next_tlb_entry, page_number, frame_number);
    }
 
    unsigned int physical_address = (frame_number << OFFSET_BITS) | offset;
    printf("\n----------------------------------------\n");
    printf("         TRANSLATION RESULT\n");
    printf("----------------------------------------\n");
    printf("Virtual Address : %u\n", virtual_address);
    printf("Page Number     : %u\n", page_number);
    printf("Offset          : %u\n", offset);
    printf("Frame Number    : %d\n", frame_number);
    if (tlb_hit) {
        printf("TLB Status      : HIT\n");
    } else {
        printf("TLB Status      : MISS\n");
    }
    printf("Physical Address: %u\n", physical_address);
    printf("----------------------------------------\n");
}
 
void run_test_cases(TLBEntry tlb[], int *next_tlb_entry, Statistics *stats) {
    printf("\n========================================\n");
    printf("           SAMPLE TEST CASES\n");
    printf("========================================\n");
    reset_tlb(tlb, next_tlb_entry);
 
    printf("\nTEST CASE 1: Address Translation\n");
    printf("Virtual Address = 4098\n");
    translate_address(tlb, next_tlb_entry, 4098, stats);
 
    printf("\nTEST CASE 2: TLB Cache Hit\n");
    printf("Accessing 4098 again...\n");
    translate_address(tlb, next_tlb_entry, 4098, stats);
 
    printf("\nTEST CASE 3: Unmapped Address\n");
    printf("Virtual Address = 20480\n");
    translate_address(tlb, next_tlb_entry, 20480, stats);
}
 
int main(void) {
    TLBEntry tlb[TLB_SIZE];
    for (int i = 0; i < TLB_SIZE; i++) {
        tlb[i].valid = 0;
        tlb[i].page = 0;
        tlb[i].frame = 0;
    }
    int next_tlb_entry = 0;
 
    Statistics stats;
    stats.total_translations = 0;
    stats.tlb_hits = 0;
    stats.tlb_misses = 0;
    stats.page_faults = 0;
 
    int choice;
    printf("========================================\n");
    printf("       PAGE TABLE & TLB SIMULATOR\n");
    printf("========================================\n");
 
    while (1) {
        printf("\n");
        printf("1. Translate Virtual Address\n");
        printf("2. Display Page Table\n");
        printf("3. Display TLB\n");
        printf("4. Run Sample Test Cases\n");
        printf("5. Display Statistics\n");
        printf("6. Reset TLB\n");
        printf("7. Exit\n");
        printf("\nEnter choice: ");
        scanf("%d", &choice);
 
        switch (choice) {
            case 1: {
                unsigned int virtual_address;
                printf("\nEnter Virtual Address: ");
                scanf("%u", &virtual_address);
                translate_address(tlb, &next_tlb_entry, virtual_address, &stats);
                break;
            }
            case 2:
                display_page_table();
                break;
            case 3:
                display_tlb(tlb);
                break;
            case 4:
                run_test_cases(tlb, &next_tlb_entry, &stats);
                break;
            case 5:
                display_statistics(&stats);
                break;
            case 6:
                reset_tlb(tlb, &next_tlb_entry);
                break;
            case 7:
                printf("\nExiting simulator...\n");
                return 0;
            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    }
    return 0;
}
